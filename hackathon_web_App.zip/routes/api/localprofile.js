const express = require('express')
const auth = require('../../middleware/auth')
const LocalProfile = require('../../models/LocalProfile')
const LocalGuide = require('../../models/LocalGuide')
const { check, validationResult } = require('express-validator')
const { update } = require('../../models/LocalGuide')

const router = express.Router()

//@route  api/localprofile/me
//get current users profile
//private

router.get('/me', auth, async (req, res) => {
    try {
        console.log(LocalProfile.findOne({ user : req.localguide.id }))
        //const localprofile = await LocalProfile.findOne({ localguide: req.localguide.id }).populate('localguide', ['name', 'avatar']);
        if (!localprofile) {
            return res.status(400).json({ msg: 'There is no profile for this user' })
        }
        res.json(localprofile);
    }
    catch (err) {
        console.error(err.message);
        res.status(500).send('server error')
    }

})

module.exports = router;