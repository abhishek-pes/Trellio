const mongoose = require('mongoose')


const LocalProfileSchema =new mongoose.Schema({
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'localguide'
    },
    place:{
        type: String,
        required: true
    },
    bio:{
        type:String
    },
    experience:{
        type:String,
        required:true

    },
    date: {
        type: Date,
        default: Date.now
      }
})

module.exports = LocalProfile = mongoose.model('localprofile', LocalProfileSchema);
